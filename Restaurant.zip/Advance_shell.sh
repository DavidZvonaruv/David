cc Advanced_shell.c -o Advanced_shell
cc CreateMenu.c -o CreateMenu
cc getMenu.c -o getMenu
cc MakeOrder.c -o MakeOrder
cc getOrderNum.c -o getOrderNum
cc getPrice.c -o getPrice
./Advanced_shell
